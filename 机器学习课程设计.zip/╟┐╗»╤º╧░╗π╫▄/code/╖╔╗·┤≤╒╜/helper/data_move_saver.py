import scipy.io as sio
import numpy as np
from time import strftime
import config.global_exp_config as gc
import config.env_robot_ql_config as ec
import os
from helper.logger_maker import get_logger
import matplotlib.pyplot as plt

def savitzky_golay(y, window_size, order, deriv=0, rate=1):
    from math import factorial
    try:
        window_size = np.abs(np.int(window_size))
        order = np.abs(np.int(order))
    except ValueError:
        raise ValueError("window_size and order have to be of type int")
    if window_size % 2 != 1 or window_size < 1:
        raise TypeError("window_size size must be a positive odd number")
    if window_size < order + 2:
        raise TypeError("window_size is too small for the polynomials order")
    order_range = range(order + 1)
    half_window = (window_size - 1) // 2
    # precompute coefficients
    b = np.mat([[k ** i for i in order_range] for k in range(-half_window, half_window + 1)])
    m = np.linalg.pinv(b).A[deriv] * rate ** deriv * factorial(deriv)
    firstvals = y[0] - np.abs(y[1:half_window + 1][::-1] - y[0])
    lastvals = y[-1] + np.abs(y[-half_window - 1:-1][::-1] - y[-1])
    y = np.concatenate((firstvals, y, lastvals))
    return np.convolve(m[::-1], y, mode='valid')


#path,filename(time),data
class DataSaver:
    def __init__(self,saver_name):
        self.logger = get_logger("DataSaver_%s" % (saver_name))

        self.saver_name = saver_name
        self.time_saver = strftime("%Y%m%d_%H%M%S")

        self.dir_name = "%s_%s" %(self.saver_name,self.time_saver)
        self.data_dir = os.path.join("results",self.dir_name)
        if not os.path.exists(self.data_dir):
            os.mkdir(self.data_dir)

        self.save_move_destination = np.zeros((gc.EPISODE_NUMBER,gc.STEP_NUMBER))
        self.save_move_distance = np.zeros((gc.EPISODE_NUMBER,gc.STEP_NUMBER))
        self.save_packet_loss = np.zeros((gc.EPISODE_NUMBER,gc.STEP_NUMBER))
        self.save_data_latency = np.zeros((gc.EPISODE_NUMBER,gc.STEP_NUMBER))
        self.save_wifi_latency = np.zeros((gc.EPISODE_NUMBER,gc.STEP_NUMBER))
        self.save_channel = np.zeros((gc.EPISODE_NUMBER,gc.STEP_NUMBER))
        self.save_utility = np.zeros((gc.EPISODE_NUMBER,gc.STEP_NUMBER))

        self.save_dict ={
            "move_destination" : self.save_move_destination,
            "move_distance"    : self.save_move_distance,
            "packet_loss"      : self.save_packet_loss,
            "data_latency"     : self.save_data_latency,
            "wifi_latency"     : self.save_wifi_latency,
            "channel"          : self.save_channel,
            "utility"          : self.save_utility
        }

    def save_step(self, episode, step, state_results,state_result_next):
        data_latency = state_result_next['data_latency']
        packet_loss = state_result_next['packet_loss']
        wifi_latency = state_result_next['wifi_latency']
        channel=state_result_next['current_channel']


        move_destiantion = state_results['move_destiantion']
        move_destiantion_next = state_result_next['move_destiantion']
        move_distance = abs(move_destiantion_next - move_destiantion)
        move_destination = state_result_next['move_destiantion']


        self.save_move_destination[episode, step] = move_destination
        self.save_move_distance[episode, step] = move_distance
        self.save_packet_loss[episode, step] = packet_loss
        self.save_data_latency[episode, step] = data_latency
        self.save_wifi_latency[episode, step] = wifi_latency
        self.save_channel[episode, step] = channel
        self.save_utility[episode, step] = ec.reward_function(state_results,state_result_next)
        channel_idx = 0 if channel == 1 else 1
        action = channel_idx*4+move_destination/2
        self.logger.info("EP:%-3d ST:%-4d MD:%-2d LO:%-3d DL:%-8.4f CH:%-2d MD:%-2d AC: %-2d,WL:%-3d",
                    episode, step,
                    move_distance, packet_loss, data_latency,channel,move_destination,action,wifi_latency)

    def save_qtable(self, episode, ql_agent):
        qtable_dir = os.path.join(self.data_dir, "Q")
        if not os.path.exists(qtable_dir):
            os.mkdir(qtable_dir)
        qtable_path = os.path.join(qtable_dir, "%d.mat" % (episode))
        ql_agent.ql.save_q(qtable_path)
        self.logger.info("Save Q: %s", qtable_path)

    def save_mat(self):
        save_mat_path = os.path.join(self.data_dir,"result.mat")
        sio.savemat(save_mat_path,self.save_dict)
        self.logger.info(self.dir_name)


    def plot_mat(self):
        plt.figure()
        plt.plot(savitzky_golay( self.save_packet_loss.mean(axis=0), 11, 1))
        plt.title("packet_loss")
        plt.figure()
        plt.plot(savitzky_golay(self.save_data_latency.mean(axis=0), 11, 1))
        plt.title("data_latency")
        plt.figure()
        plt.plot(savitzky_golay(self.save_move_distance.mean(axis=0), 11, 1))
        plt.title("move_distance")
        plt.figure()
        plt.show()
        plt.plot(savitzky_golay(self.save_utility.mean(axis=0), 11, 1))
        plt.title("utility")
        plt.figure()
        plt.plot(savitzky_golay(self.save_wifi_latency.mean(axis=0), 11, 1))
        plt.title("wifi_latency")
        plt.figure()
        plt.show()

