# -*- coding: utf-8 -*-
import torch
import numpy as np
from data import env
import cv2
from itertools import chain
from algorithms.DQN_module import Agent
use_cuda = torch.cuda.is_available()
FloatTensor = torch.cuda.FloatTensor if use_cuda else torch.FloatTensor
LongTensor = torch.cuda.LongTensor if use_cuda else torch.LongTensor
ByteTensor = torch.cuda.ByteTensor if use_cuda else torch.ByteTensor

Tensor = FloatTensor
env = env.Env()


dis = 0.9
REPLAY_MEMORY = 50000

def ob_process(frame):

    frame = cv2.resize(frame, (84, 84), interpolation=cv2.INTER_AREA)
    #frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # frame=frame.astype('float64')
    # frame=torch.from_numpy(frame)
    # frame=frame.unsqueeze(0).type(Tensor)
    frame=frame.tolist()
    return frame


def main():
    params = {
        'gamma': 0.8,
        'epsi_high': 0.8,
        'epsi_low': 0.02,
        'decay': 400,
        'lr': 0.001,
        'capacity': 10000,
        'batch_size': 64,
        'state_space_dim': 7057,
        'action_space_dim': 13
    }
    EPS_END=0.02
    EPS_START=0.9
    EPS_DECAY=400
    agent = Agent(**params)
    history_distance=200
    judge_distance=0
    epi_total_reward_list=[]
    max_episodes = 2000
    s1=0
    s2=0
    agent.load_model("wan", "D:/仿真/2020.12.13/")

    for episode in range(max_episodes):
        done = False
        step_count = 0
        episode_total_reward=0
        env.reset()
        state, reward, done,s4,s5,s6,s7=env.step(0)
        state = ob_process(state)
        state=list(chain(*state))
        state.append(s7)

        cv2.waitKey(0)
        cv2.destroyAllWindows()
        while not done:
            epsi = EPS_END + (EPS_START - EPS_END) * np.math.exp(-1 * episode / EPS_DECAY)
            action_index = agent.act(state,epsi)
            reward_n=0

            for i in range(10):
                next_state, reward, done, _, max_distance, _, now_distance = env.step(action_index)
                cv2.waitKey(action_index)
                reward_n=reward_n+reward
            # print("4     :", np.size(next_state))
            if now_distance>=2800:
                print(now_distance)
            if now_distance<=2900 and now_distance>=2800:
                for i in range(10):
                    next_state, reward, done, s1, max_distance, s2, now_distance = env.step(8)
                    cv2.waitKey(action_index)
            if now_distance<=3650 and now_distance>=3660:
                for i in range(10):
                    next_state, reward, done, s1, max_distance, s2, now_distance = env.step(8)
                    cv2.waitKey(action_index)
            if now_distance<=6555 and now_distance>=6469:
                for i in range(10):
                    next_state, reward, done, s1, max_distance, s2, now_distance = env.step(8)
                    cv2.waitKey(action_index)
            episode_total_reward += reward_n
            next_state = ob_process(next_state)
            next_state = list(chain(*next_state))
            next_state.append(now_distance)
            # print( reward, done, s1, max_distance, s2, now_distance)
            # print("5     :", np.size(next_state))
            # print(type(next_state))
            # print(type([reward_n,max_distance]))
            if done == True :
                env.reset()
                epi_total_reward_list.append(episode_total_reward)
                print('episode %d total reward=%.2f'%(episode,episode_total_reward))
                episode_total_reward = 0

            # print("6     :", np.size(state))
            # print("7     :", np.size(next_state))
            agent.put(state, action_index, reward_n, next_state)
            agent.learn()
            if done == False :
                state = next_state
                step_count += 1
            if now_distance <= history_distance:
                judge_distance += 1
            else:
                judge_distance = 0
                history_distance = max_distance

        agent.save_model("wan", "D:/仿真/2020.12.13/")



if __name__ == "__main__":
    main()
