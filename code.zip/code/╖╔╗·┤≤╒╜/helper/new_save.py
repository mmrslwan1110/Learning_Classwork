import scipy.io as sio
import numpy as np
from time import strftime
# import config.global_exp_config as gc
# import  config.env_robot_config as ec
import os
from helper.logger_maker import get_logger
import matplotlib.pyplot as plt

def savitzky_golay(y, window_size, order, deriv=0, rate=1):
    from math import factorial
    try:
        window_size = np.abs(np.int(window_size))
        order = np.abs(np.int(order))
    except ValueError:
        raise ValueError("window_size and order have to be of type int")
    if window_size % 2 != 1 or window_size < 1:
        raise TypeError("window_size size must be a positive odd number")
    if window_size < order + 2:
        raise TypeError("window_size is too small for the polynomials order")
    order_range = range(order + 1)
    half_window = (window_size - 1) // 2
    # precompute coefficients
    b = np.mat([[k ** i for i in order_range] for k in range(-half_window, half_window + 1)])
    m = np.linalg.pinv(b).A[deriv] * rate ** deriv * factorial(deriv)
    firstvals = y[0] - np.abs(y[1:half_window + 1][::-1] - y[0])
    lastvals = y[-1] + np.abs(y[-half_window - 1:-1][::-1] - y[-1])
    y = np.concatenate((firstvals, y, lastvals))
    return np.convolve(m[::-1], y, mode='valid')


#path,filename(time),data
class DataSaver:
    def __init__(self,saver_name):
        self.logger = get_logger("DataSaver_%s" % (saver_name))

        self.saver_name = saver_name
        self.time_saver = strftime("%Y%m%d_%H%M%S")

        self.dir_name = "%s_%s" %(self.saver_name,self.time_saver)
        self.data_dir = os.path.join("results",self.dir_name)
        if not os.path.exists(self.data_dir):
            os.mkdir(self.data_dir)


        self.save_action = np.zeros((5000,5000))
        self.save_utility = np.zeros((5000,5000))

        self.save_dict ={
            "action"          : self.save_action,
            "utility"          : self.save_utility
        }

    def save_step(self,episode, step, reward,action_index):


        self.save_action[episode, step] = action_index
        self.save_utility[episode, step] = reward
        self.logger.info("EP:%-3d ST:%-4d RD:%-2f AC:%-3d",
                    episode, step,
                    reward, action_index)

    def save_qtable(self, episode, ql_agent):
        qtable_dir = os.path.join(self.data_dir, "Q")
        if not os.path.exists(qtable_dir):
            os.mkdir(qtable_dir)
        qtable_path = os.path.join(qtable_dir, "%d.mat" % (episode))
        ql_agent.ql.save_q(qtable_path)
        self.logger.info("Save Q: %s", qtable_path)

    def save_mat(self):
        save_mat_path = os.path.join(self.data_dir,"result.mat")
        sio.savemat(save_mat_path,self.save_dict)
        self.logger.info(self.dir_name)


    def plot_mat(self):
        plt.figure()
        plt.plot(savitzky_golay( self.save_packet_loss.mean(axis=0), 11, 1))
        plt.title("packet_loss")
        plt.figure()
        plt.plot(savitzky_golay(self.save_data_latency.mean(axis=0), 11, 1))
        plt.title("data_latency")
        plt.figure()
        plt.plot(savitzky_golay(self.save_move_distance.mean(axis=0), 11, 1))
        plt.title("move_distance")
        plt.figure()
        plt.show()
        plt.plot(savitzky_golay(self.save_utility.mean(axis=0), 11, 1))
        plt.title("utility")
        plt.figure()
        plt.plot(savitzky_golay(self.save_wifi_latency.mean(axis=0), 11, 1))
        plt.title("wifi_latency")
        plt.figure()
        plt.show()

