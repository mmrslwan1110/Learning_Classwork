# -------------------------
# Project: Deep Q-Learning on Plane
# Author: bc_zhang
# Date: 2019.2.12
# -------------------------
from itertools import chain
from helper.new_save import DataSaver
import cv2
import sys
sys.path.append("game/")
import game.plane as game
import numpy as np
from algorithms.DQN_module import Agent
CODE_VERSION = "DQN_v1_Adame"

def preprocess(observation):
	observation = cv2.cvtColor(cv2.resize(observation, (80, 80)), cv2.COLOR_BGR2GRAY)#灰度转化
	ret, observation = cv2.threshold(observation,1,255,cv2.THRESH_BINARY)
	observation = cv2.resize(observation, (80, 80), interpolation=cv2.INTER_AREA)
	observation = observation.tolist()
	return observation

def playPlane():
	saver = DataSaver(CODE_VERSION)
	plane = game.GameState()
	params = {
		'gamma': 0.8,
		'epsi_high': 0.8,
		'epsi_low': 0.02,
		'decay': 400,
		'lr': 0.001,
		'capacity': 10000,
		'batch_size': 64,
		'state_space_dim': 6400,
		'action_space_dim': 3
	}
	EPS_END = 0.02
	EPS_START = 0.9
	EPS_DECAY = 400

	action =np.array([[0,1,0],[0,0,1],[1,0,0]])
	max_episodes=5000
	agent = Agent(**params)
	agent.load_model("fly", "D:/仿真/2020.12.13/")
	for episode in range(max_episodes):
		state, reward, terminal = plane.frame_step(action[0])
		state = preprocess(state)
		state = list(chain(*state))
		epsi = EPS_END + (EPS_START - EPS_END) * np.math.exp(-1 * episode / EPS_DECAY)
		# print(epsi)
		reward_all=reward
		step=0
		while not terminal:
			action_index = agent.act(state,epsi)
			next_state,reward,terminal = plane.frame_step(action[action_index])
			next_state = preprocess(next_state)
			next_state = list(chain(*next_state))
			agent.put(state, action_index, reward, next_state)
			agent.learn()
			state = next_state
			reward_all=reward+reward_all
			step=step+1
			saver.save_step(episode, step, reward,action_index)

		print("episode :",episode,"reward :",reward_all)
		agent.save_model("fly", "D:/仿真/2020.12.13/")
	saver.save_mat()
	saver.plot_mat()
def main():
	playPlane()

if __name__ == '__main__':
	main()