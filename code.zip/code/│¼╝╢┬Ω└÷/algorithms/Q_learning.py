# -*- coding: utf-8 -*-
import random
# import gym
import time
import numpy as np
from collections import defaultdict
import scipy.io as sio
from tqdm import tqdm
import math
import pylab
import matplotlib.pyplot as plt


class QLearningAgent(object):
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)
        self.__state_size = self.state_size
        #self.q_table = defaultdict(lambda: [0.0, 0.0, 0.0, 0.0])
        self.q_table = np.zeros((self.state_space_dim, self.action_space_dim))
        self.gamma=0.8
        self.steps = 0

    # 采样 <s, a, r, s'>
    def learn(self, state, action, reward, next_state):
        q_next = self.q_table[next_state].max()
        self.q_table[state, action] = (1 - self.learning_rate) * self.q_table[state, action] + self.learning_rate * (reward + self.gamma * q_next)

    # 从Q-table中选取动作
    def get_action(self, state):
        self.steps += 1

        epsi = self.epsi_low + (self.epsi_high - self.epsi_low) * (math.exp(-2.0 * self.steps / self.decay))

        state_idx = self.__getStateIdx(state)
        state_idx=int(state_idx)
        if np.random.rand() < epsi:
            # 贪婪策略随机探索动作
            action = random.randrange(self.action_space_dim)
        else:
            # 从q表中选择
            max_actions = np.where(self.q_table[state] == self.q_table[state].max())[0]
            action = np.random.choice(max_actions)
        return action

    def plot(self, mean, str):

        pylab.figure(1)
        pylab.xlabel('Episodes')
        pylab.ylabel('Average Reward')

        pylab.plot(mean, label=str)
        pylab.legend(loc='best')
        #plt.axis([0,len(mean),0,max(mean)+1])  #plt.axis([minx, maxx, miny, maxy])
        #pylab.title('eje')
        pylab.grid(True,linestyle='-.')


        pylab.show()
    def __getStateIdx(self, idx_set):
        state_size_tmp = np.delete(self.__state_size, 0)
        state_size_tmp = np.append(state_size_tmp, 1)
        state_size_reverse = np.flip(state_size_tmp, axis=0)
        coo = np.cumprod(state_size_reverse)
        coo = np.flip(coo, axis=0)
        # print(idx_set)
        # print(coo)
        return sum(idx_set * coo)
    def reset(self):
        self.q_table = np.zeros((self.__state_size,self.action_space_dim))



    # #####################
    # params_t = {
    #     'state_size':36,
    #     'discount_factor': 0.8,
    #     'epsi_high': 0.8,
    #     'epsi_low': 0.01,
    #     'decay': 6000,
    #     'learning_rate': 0.5,
    #     'state_space_dim': 36,  # 500
    #     'action_space_dim': Num_action_t  # 6
    #
    # }